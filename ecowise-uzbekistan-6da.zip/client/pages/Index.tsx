import Navigation from "@/components/Navigation";
import Footer from "@/components/Footer";
import Hero from "@/components/sections/Hero";
import About from "@/components/sections/About";
import Events from "@/components/sections/Events";
import Regions from "@/components/sections/Regions";
import Reviews from "@/components/sections/Reviews";
import Team from "@/components/sections/Team";
import Contact from "@/components/sections/Contact";

export default function Index() {
  return (
    <div className="w-full">
      {/* Navigation */}
      <Navigation />

      {/* Main Content */}
      <main className="pt-20">
        {/* Hero Section */}
        <Hero />

        {/* About Section */}
        <About />

        {/* Events Section */}
        <Events />

        {/* Regions Section */}
        <Regions />

        {/* Reviews Section */}
        <Reviews />

        {/* Team Section */}
        <Team />

        {/* Contact Section */}
        <Contact />
      </main>

      {/* Footer */}
      <Footer />
    </div>
  );
}
