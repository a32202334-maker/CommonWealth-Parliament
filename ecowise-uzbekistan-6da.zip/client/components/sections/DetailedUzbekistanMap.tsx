import { useState } from "react";
import { MapPin } from "lucide-react";

interface RegionData {
  id: string;
  name: string;
  events: number;
  participants: number;
  ambassadors: number;
  pinX: number;
  pinY: number;
}

const regions: RegionData[] = [
  { id: "karakalpakstan", name: "Karakalpakstan", events: 0, participants: 0, ambassadors: 1, pinX: 180, pinY: 150 },
  { id: "navoi", name: "Navoi Region", events: 0, participants: 0, ambassadors: 1, pinX: 320, pinY: 220 },
  { id: "bukhara", name: "Bukhara Region", events: 1, participants: 15, ambassadors: 1, pinX: 380, pinY: 300 },
  { id: "kashkadarya", name: "Kashkadarya Region", events: 1, participants: 18, ambassadors: 1, pinX: 450, pinY: 380 },
  { id: "surkhandarya", name: "Surkhondarya Region", events: 0, participants: 0, ambassadors: 0, pinX: 520, pinY: 420 },
  { id: "jizzakh", name: "Jizzakh Region", events: 1, participants: 12, ambassadors: 1, pinX: 480, pinY: 280 },
  { id: "samarkand", name: "Samarkand Region", events: 0, participants: 0, ambassadors: 1, pinX: 420, pinY: 220 },
  { id: "tashkent", name: "Tashkent Region", events: 1, participants: 25, ambassadors: 2, pinX: 520, pinY: 180 },
  { id: "tashkent-city", name: "Tashkent City", events: 2, participants: 45, ambassadors: 3, pinX: 550, pinY: 170 },
  { id: "namangan", name: "Namangan Region", events: 0, participants: 0, ambassadors: 1, pinX: 580, pinY: 150 },
  { id: "fergana", name: "Fergana Region", events: 1, participants: 20, ambassadors: 1, pinX: 620, pinY: 180 },
  { id: "andijan", name: "Andijan Region", events: 2, participants: 30, ambassadors: 2, pinX: 660, pinY: 160 },
];

interface Tooltip {
  region: RegionData;
  x: number;
  y: number;
}

export default function DetailedUzbekistanMap() {
  const [tooltip, setTooltip] = useState<Tooltip | null>(null);
  const [hoveredRegion, setHoveredRegion] = useState<string | null>(null);

  const handlePinHover = (region: RegionData, e: React.MouseEvent<SVGGElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    setTooltip({
      region,
      x: rect.x + rect.width / 2,
      y: rect.y - 10,
    });
    setHoveredRegion(region.id);
  };

  const handleMouseLeave = () => {
    setTooltip(null);
    setHoveredRegion(null);
  };

  return (
    <div className="relative w-full h-full">
      {/* SVG Map Container */}
      <div className="w-full h-[600px] bg-gradient-to-b from-blue-50 to-blue-100 dark:from-gray-800 dark:to-gray-900 rounded-2xl overflow-hidden border-2 border-blue-200 dark:border-gray-700 flex items-center justify-center">
        <svg
          viewBox="0 0 800 550"
          className="w-full h-full"
          preserveAspectRatio="xMidYMid meet"
        >
          {/* Define gradients and patterns */}
          <defs>
            <linearGradient id="waterGradient" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#e0f2fe" />
              <stop offset="100%" stopColor="#bae6fd" />
            </linearGradient>
            <pattern id="dots" x="20" y="20" width="20" height="20" patternUnits="userSpaceOnUse">
              <circle cx="10" cy="10" r="1.5" fill="currentColor" fillOpacity="0.08" />
            </pattern>
            <filter id="regionHover">
              <feGaussianBlur in="SourceGraphic" stdDeviation="2" />
            </filter>
          </defs>

          {/* Background */}
          <rect width="800" height="550" fill="url(#waterGradient)" />
          <rect width="800" height="550" fill="url(#dots)" />

          {/* DETAILED REGION PATHS - More accurate boundaries */}

          {/* Karakalpakstan - Separated on left */}
          <path
            d="M 30 40 L 150 60 L 160 200 L 40 220 Z"
            fill={hoveredRegion === "karakalpakstan" ? "#a3f6c1" : "#c8e6c9"}
            stroke="#22c55e"
            strokeWidth="2"
            className="cursor-pointer transition-all duration-300 hover:brightness-110"
          />

          {/* Navoi Region */}
          <path
            d="M 150 60 L 280 80 L 310 200 L 240 240 L 200 160 Z"
            fill={hoveredRegion === "navoi" ? "#a3f6c1" : "#c8e6c9"}
            stroke="#22c55e"
            strokeWidth="2"
            className="cursor-pointer transition-all duration-300 hover:brightness-110"
          />

          {/* Samarkand Region - Central */}
          <path
            d="M 280 80 L 380 100 L 420 180 L 380 240 L 310 200 Z"
            fill={hoveredRegion === "samarkand" ? "#a3f6c1" : "#c8e6c9"}
            stroke="#22c55e"
            strokeWidth="2"
            className="cursor-pointer transition-all duration-300 hover:brightness-110"
          />

          {/* Bukhara Region */}
          <path
            d="M 200 160 L 240 240 L 320 320 L 280 380 L 180 340 L 150 220 Z"
            fill={hoveredRegion === "bukhara" ? "#a3f6c1" : "#c8e6c9"}
            stroke="#22c55e"
            strokeWidth="2"
            className="cursor-pointer transition-all duration-300 hover:brightness-110"
          />

          {/* Jizzakh Region */}
          <path
            d="M 310 200 L 380 180 L 420 260 L 380 320 Z"
            fill={hoveredRegion === "jizzakh" ? "#a3f6c1" : "#c8e6c9"}
            stroke="#22c55e"
            strokeWidth="2"
            className="cursor-pointer transition-all duration-300 hover:brightness-110"
          />

          {/* Kashkadarya Region */}
          <path
            d="M 320 320 L 380 260 L 450 280 L 480 380 L 400 420 Z"
            fill={hoveredRegion === "kashkadarya" ? "#a3f6c1" : "#c8e6c9"}
            stroke="#22c55e"
            strokeWidth="2"
            className="cursor-pointer transition-all duration-300 hover:brightness-110"
          />

          {/* Surkhondarya Region */}
          <path
            d="M 450 280 L 520 300 L 560 420 L 480 380 Z"
            fill={hoveredRegion === "surkhandarya" ? "#a3f6c1" : "#c8e6c9"}
            stroke="#22c55e"
            strokeWidth="2"
            className="cursor-pointer transition-all duration-300 hover:brightness-110"
          />

          {/* Tashkent Region */}
          <path
            d="M 420 100 L 520 110 L 560 160 L 520 200 L 460 160 Z"
            fill={hoveredRegion === "tashkent" ? "#a3f6c1" : "#c8e6c9"}
            stroke="#22c55e"
            strokeWidth="2"
            className="cursor-pointer transition-all duration-300 hover:brightness-110"
          />

          {/* Namangan Region */}
          <path
            d="M 520 110 L 600 100 L 640 160 L 580 200 L 520 200 Z"
            fill={hoveredRegion === "namangan" ? "#a3f6c1" : "#c8e6c9"}
            stroke="#22c55e"
            strokeWidth="2"
            className="cursor-pointer transition-all duration-300 hover:brightness-110"
          />

          {/* Fergana Region */}
          <path
            d="M 600 100 L 680 90 L 720 180 L 680 220 L 640 160 Z"
            fill={hoveredRegion === "fergana" ? "#a3f6c1" : "#c8e6c9"}
            stroke="#22c55e"
            strokeWidth="2"
            className="cursor-pointer transition-all duration-300 hover:brightness-110"
          />

          {/* Andijan Region */}
          <path
            d="M 680 90 L 750 100 L 760 200 L 720 180 Z"
            fill={hoveredRegion === "andijan" ? "#a3f6c1" : "#c8e6c9"}
            stroke="#22c55e"
            strokeWidth="2"
            className="cursor-pointer transition-all duration-300 hover:brightness-110"
          />

          {/* LOCATION PINS WITH ICONS */}
          {regions.map((region) => (
            <g
              key={region.id}
              onMouseEnter={(e) => handlePinHover(region, e)}
              onMouseLeave={handleMouseLeave}
              className="cursor-pointer"
            >
              {/* Pin Shadow */}
              <ellipse
                cx={region.pinX}
                cy={region.pinY + 35}
                rx="8"
                ry="4"
                fill="rgba(0, 0, 0, 0.1)"
              />

              {/* Pin Marker - Outer Circle */}
              <circle
                cx={region.pinX}
                cy={region.pinY}
                r="18"
                fill="#ffffff"
                stroke="#22c55e"
                strokeWidth="2.5"
                className="transition-all duration-300"
                style={{
                  filter: hoveredRegion === region.id ? "drop-shadow(0 0 12px rgba(34, 197, 94, 0.8))" : "drop-shadow(0 3px 8px rgba(0, 0, 0, 0.2))",
                  transform: hoveredRegion === region.id ? "scale(1.3)" : "scale(1)",
                }}
              />

              {/* Pin Icon - Dollar sign or event icon */}
              <text
                x={region.pinX}
                y={region.pinY + 6}
                textAnchor="middle"
                className="font-bold select-none"
                fontSize="20"
                fill="#22c55e"
              >
                {region.events > 0 ? "🎯" : "📍"}
              </text>

              {/* Pin Pointer */}
              <path
                d={`M ${region.pinX},${region.pinY + 18} L ${region.pinX - 6},${region.pinY + 28} L ${region.pinX},${region.pinY + 32} L ${region.pinX + 6},${region.pinY + 28} Z`}
                fill="#ffffff"
                stroke="#22c55e"
                strokeWidth="1.5"
              />
            </g>
          ))}

          {/* Region Labels */}
          <text x="90" y="130" textAnchor="middle" className="text-xs font-bold fill-gray-700 dark:fill-gray-300 pointer-events-none" fontSize="10">
            Karakalpakstan
          </text>
          <text x="240" y="145" textAnchor="middle" className="text-xs font-bold fill-gray-700 dark:fill-gray-300 pointer-events-none" fontSize="10">
            Navoi
          </text>
          <text x="340" y="135" textAnchor="middle" className="text-xs font-bold fill-gray-700 dark:fill-gray-300 pointer-events-none" fontSize="10">
            Samarkand
          </text>
          <text x="250" y="270" textAnchor="middle" className="text-xs font-bold fill-gray-700 dark:fill-gray-300 pointer-events-none" fontSize="10">
            Bukhara
          </text>
          <text x="360" y="260" textAnchor="middle" className="text-xs font-bold fill-gray-700 dark:fill-gray-300 pointer-events-none" fontSize="10">
            Jizzakh
          </text>
          <text x="420" y="350" textAnchor="middle" className="text-xs font-bold fill-gray-700 dark:fill-gray-300 pointer-events-none" fontSize="10">
            Kashkadarya
          </text>
          <text x="520" y="360" textAnchor="middle" className="text-xs font-bold fill-gray-700 dark:fill-gray-300 pointer-events-none" fontSize="10">
            Surkhondarya
          </text>
          <text x="490" y="140" textAnchor="middle" className="text-xs font-bold fill-gray-700 dark:fill-gray-300 pointer-events-none" fontSize="10">
            Tashkent Reg.
          </text>
          <text x="570" y="145" textAnchor="middle" className="text-xs font-bold fill-gray-700 dark:fill-gray-300 pointer-events-none" fontSize="10">
            Namangan
          </text>
          <text x="660" y="135" textAnchor="middle" className="text-xs font-bold fill-gray-700 dark:fill-gray-300 pointer-events-none" fontSize="10">
            Fergana
          </text>
          <text x="720" y="145" textAnchor="middle" className="text-xs font-bold fill-gray-700 dark:fill-gray-300 pointer-events-none" fontSize="10">
            Andijan
          </text>
        </svg>
      </div>

      {/* Tooltip */}
      {tooltip && (
        <div
          className="fixed bg-white dark:bg-gray-800 rounded-2xl shadow-2xl p-4 border-2 border-emerald-500 dark:border-emerald-400 z-50 w-80 animate-scale-in"
          style={{
            left: `${tooltip.x}px`,
            top: `${tooltip.y}px`,
            transform: "translate(-50%, -100%)",
          }}
        >
          {/* Tooltip Header */}
          <div className="flex items-center gap-2 mb-3">
            <div className="w-3 h-3 bg-emerald-500 rounded-full" />
            <h3 className="font-bold text-gray-900 dark:text-white text-lg">
              {tooltip.region.name}
            </h3>
          </div>

          {/* Tooltip Content */}
          <p className="text-sm text-gray-600 dark:text-gray-400 mb-4">
            {tooltip.region.events > 0
              ? `${tooltip.region.events} ecological competition${tooltip.region.events > 1 ? "s" : ""}`
              : "Joining EcoWise soon"}
          </p>

          {/* Stats Grid */}
          <div className="grid grid-cols-3 gap-2">
            <div className="bg-emerald-50 dark:bg-emerald-900/30 rounded-lg p-2 text-center">
              <div className="text-xl font-bold text-emerald-600 dark:text-emerald-400">
                {tooltip.region.events}
              </div>
              <div className="text-xs text-gray-600 dark:text-gray-400">Events</div>
            </div>
            <div className="bg-blue-50 dark:bg-blue-900/30 rounded-lg p-2 text-center">
              <div className="text-xl font-bold text-blue-600 dark:text-blue-400">
                {tooltip.region.participants}
              </div>
              <div className="text-xs text-gray-600 dark:text-gray-400">Participants</div>
            </div>
            <div className="bg-purple-50 dark:bg-purple-900/30 rounded-lg p-2 text-center">
              <div className="text-xl font-bold text-purple-600 dark:text-purple-400">
                {tooltip.region.ambassadors}
              </div>
              <div className="text-xs text-gray-600 dark:text-gray-400">Ambassadors</div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
