import { CheckCircle, Users, Target, Lightbulb } from "lucide-react";

export default function About() {
  return (
    <section id="about" className="section bg-white dark:bg-gray-900">
      <div className="container-main">
        {/* Section Header */}
        <div className="text-center mb-16">
          <h2 className="section-title text-primary">About Commonwealth Youth Parliament</h2>
          <p className="section-subtitle">
            Empowering young voices in democratic governance
          </p>
        </div>

        {/* Two Column Layout */}
        <div className="grid lg:grid-cols-2 gap-12 items-center mb-16">
          {/* Left Column - Content */}
          <div className="space-y-8">
            {/* Who We Are */}
            <div className="animate-fade-in-up">
              <h3 className="text-3xl font-bold text-gray-900 dark:text-white mb-4">Who are we?</h3>
              <p className="text-gray-600 dark:text-gray-300 leading-relaxed">
                Commonwealth Youth Parliament is a youth-led initiative dedicated to developing the next generation of parliamentary leaders. We're passionate about fostering democratic engagement and political awareness among young people across the region.
              </p>
            </div>

            {/* Our Mission */}
            <div className="animate-fade-in-up" style={{ animationDelay: "0.1s" }}>
              <h3 className="text-3xl font-bold text-gray-900 dark:text-white mb-4">Our Mission</h3>
              <p className="text-gray-600 dark:text-gray-300 leading-relaxed mb-6">
                Democracy in Action: We believe civic engagement happens best through participation and mentorship. Our programs bring together students, educators, and parliamentary professionals.
              </p>

              {/* Key Points */}
              <div className="space-y-3">
                {["Parliamentary Training Programs", "Mentorship from Political Leaders", "Regional Youth Engagement"].map(
                  (point, index) => (
                    <div key={index} className="flex items-start gap-3">
                      <CheckCircle className="w-6 h-6 text-emerald flex-shrink-0 mt-1" />
                      <span className="text-gray-700 dark:text-gray-300">{point}</span>
                    </div>
                  )
                )}
              </div>
            </div>

            {/* CTA Button */}
            <div className="animate-fade-in-up" style={{ animationDelay: "0.2s" }}>
              <a
                href="https://t.me/cwypsecretariat"
                target="_blank"
                rel="noopener noreferrer"
                className="btn btn-primary inline-block"
              >
                Connect With Us
              </a>
            </div>
          </div>

          {/* Right Column - Interactive Cards */}
          <div className="grid grid-cols-2 gap-6 animate-fade-in-up" style={{ animationDelay: "0.1s" }}>
            {/* Card 1 - Red */}
            <div className="bg-gradient-to-br from-red-50 to-red-100 dark:from-red-900/20 dark:to-red-800/10 rounded-2xl p-6 border-2 border-red-200 dark:border-red-700 hover:shadow-lg hover:-translate-y-2 transition-all">
              <div className="text-4xl mb-4">📋</div>
              <h4 className="font-bold text-gray-900 dark:text-white mb-2">Governance</h4>
              <p className="text-sm text-gray-600 dark:text-gray-400">Learn parliamentary procedures and democratic processes</p>
            </div>

            {/* Card 2 - Blue */}
            <div className="bg-gradient-to-br from-blue-50 to-blue-100 dark:from-blue-900/20 dark:to-blue-800/10 rounded-2xl p-6 border-2 border-blue-200 dark:border-blue-700 hover:shadow-lg hover:-translate-y-2 transition-all">
              <div className="text-4xl mb-4">🎤</div>
              <h4 className="font-bold text-gray-900 dark:text-white mb-2">Leadership</h4>
              <p className="text-sm text-gray-600 dark:text-gray-400">Develop speaking and leadership skills</p>
            </div>

            {/* Card 3 - Green */}
            <div className="bg-gradient-to-br from-emerald-50 to-emerald-100 dark:from-emerald-900/20 dark:to-emerald-800/10 rounded-2xl p-6 border-2 border-emerald-200 dark:border-emerald-700 hover:shadow-lg hover:-translate-y-2 transition-all">
              <div className="text-4xl mb-4">🤝</div>
              <h4 className="font-bold text-gray-900 dark:text-white mb-2">Networking</h4>
              <p className="text-sm text-gray-600 dark:text-gray-400">Connect with youth leaders from across regions</p>
            </div>

            {/* Card 4 - Yellow */}
            <div className="bg-gradient-to-br from-yellow-50 to-yellow-100 dark:from-yellow-900/20 dark:to-yellow-800/10 rounded-2xl p-6 border-2 border-yellow-200 dark:border-yellow-700 hover:shadow-lg hover:-translate-y-2 transition-all">
              <div className="text-4xl mb-4">⭐</div>
              <h4 className="font-bold text-gray-900 dark:text-white mb-2">Impact</h4>
              <p className="text-sm text-gray-600 dark:text-gray-400">Make a real difference in your community</p>
            </div>
          </div>
        </div>

        {/* Values Section */}
        <div className="bg-gradient-to-r from-primary/5 to-emerald/5 dark:from-gray-800 dark:to-gray-800 rounded-3xl p-12">
          <h3 className="text-2xl font-bold text-gray-900 dark:text-white mb-8 text-center">Our Core Values</h3>
          <div className="grid md:grid-cols-4 gap-6">
            {[
              { icon: Target, label: "Integrity", color: "text-red-500" },
              { icon: Users, label: "Inclusivity", color: "text-blue-500" },
              { icon: Lightbulb, label: "Innovation", color: "text-emerald-500" },
              { icon: CheckCircle, label: "Excellence", color: "text-yellow-500" },
            ].map((value, index) => (
              <div key={index} className="text-center animate-fade-in-up" style={{ animationDelay: `${index * 0.1}s` }}>
                <value.icon className={`w-12 h-12 ${value.color} mx-auto mb-4`} />
                <h4 className="font-bold text-gray-900 dark:text-white">{value.label}</h4>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
