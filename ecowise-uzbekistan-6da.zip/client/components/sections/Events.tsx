import { useState } from "react";
import { Calendar, Users, MapPin, Zap } from "lucide-react";

interface Event {
  id: number;
  title: string;
  date: string;
  type: string;
  description: string;
  participants: number;
  location: string;
  color: "red" | "blue" | "green" | "yellow";
  icon: string;
}

const events: Event[] = [
  {
    id: 1,
    title: "Spring Parliamentary Summit",
    date: "August 10, 2025",
    type: "Conference",
    description: "Major gathering of youth parliamentary leaders for debate and discussion",
    participants: 150,
    location: "Tashkent",
    color: "red",
    icon: "🏛️",
  },
  {
    id: 2,
    title: "Youth Leadership Workshop",
    date: "September 28, 2025",
    type: "Workshop",
    description: "Intensive training on public speaking and parliamentary procedures",
    participants: 85,
    location: "Samarkand",
    color: "blue",
    icon: "🎓",
  },
  {
    id: 3,
    title: "Regional Council Meeting",
    date: "March 6-7, 2025",
    type: "Meeting",
    description: "Quarterly gathering of regional youth representatives",
    participants: 120,
    location: "Bukhara",
    color: "green",
    icon: "📍",
  },
  {
    id: 4,
    title: "Democracy Day Celebration",
    date: "October 11, 2025",
    type: "Campaign",
    description: "Community engagement and awareness building initiative",
    participants: 200,
    location: "Fergana Valley",
    color: "yellow",
    icon: "🎉",
  },
];

const colorClasses = {
  red: "from-red-500 to-red-600",
  blue: "from-blue-500 to-blue-600",
  green: "from-lime-400 to-green-500",
  yellow: "from-yellow-500 to-yellow-600",
};

const colorBadges = {
  red: "bg-red-100 dark:bg-red-900/30 text-red-700 dark:text-red-300",
  blue: "bg-blue-100 dark:bg-blue-900/30 text-blue-700 dark:text-blue-300",
  green: "bg-lime-100 dark:bg-lime-900/30 text-lime-700 dark:text-lime-300",
  yellow: "bg-yellow-100 dark:bg-yellow-900/30 text-yellow-700 dark:text-yellow-300",
};

export default function Events() {
  const [filter, setFilter] = useState("all");

  const filters = ["all", "Conference", "Workshop"];

  const filteredEvents = events.filter((event) => {
    if (filter === "all") return true;
    return event.type === filter;
  });

  return (
    <section id="events" className="section bg-gradient-events">
      <div className="container-main">
        {/* Section Header */}
        <div className="text-center mb-12">
          <h2 className="section-title text-primary">Parliamentary Events</h2>
          <p className="section-subtitle">Explore our parliamentary programs and youth initiatives</p>
        </div>

        {/* Filters */}
        <div className="flex flex-wrap gap-3 justify-center mb-12">
          {filters.map((f) => (
            <button
              key={f}
              onClick={() => setFilter(f)}
              className={`px-6 py-2 rounded-full font-medium transition-all duration-300 ${
                filter === f
                  ? "bg-primary text-white shadow-lg scale-105"
                  : "bg-white dark:bg-gray-800 text-gray-700 dark:text-gray-300 hover:shadow-md"
              }`}
            >
              {f === "all" ? "All Events" : f}
            </button>
          ))}
        </div>

        {/* Events Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {filteredEvents.map((event, index) => (
            <div
              key={event.id}
              className={`group relative overflow-hidden rounded-2xl p-6 text-white bg-gradient-to-br ${colorClasses[event.color]} transition-all duration-300 hover:shadow-2xl hover:-translate-y-2 animate-fade-in-up`}
              style={{
                animationDelay: `${index * 0.1}s`,
              }}
            >
              {/* Content */}
              <div className="relative z-10">
                {/* Icon */}
                <div className="text-5xl mb-4">{event.icon}</div>

                {/* Type Badge */}
                <span className={`inline-block px-3 py-1 rounded-full text-xs font-bold mb-3 ${colorBadges[event.color]}`}>
                  {event.type}
                </span>

                {/* Title */}
                <h3 className="text-xl font-bold mb-3 group-hover:translate-x-2 transition-transform">
                  {event.title}
                </h3>

                {/* Description */}
                <p className="text-sm opacity-90 mb-4 line-clamp-2">
                  {event.description}
                </p>

                {/* Stats */}
                <div className="space-y-2 pt-4 border-t border-white/20">
                  {/* Date */}
                  <div className="flex items-center gap-2 text-sm opacity-90">
                    <Calendar size={16} />
                    <span>{event.date}</span>
                  </div>

                  {/* Location */}
                  <div className="flex items-center gap-2 text-sm opacity-90">
                    <MapPin size={16} />
                    <span>{event.location}</span>
                  </div>

                  {/* Participants */}
                  <div className="flex items-center gap-2 text-sm opacity-90">
                    <Users size={16} />
                    <span>{event.participants} participants</span>
                  </div>
                </div>
              </div>

              {/* Hover Effect - Zap */}
              <div className="absolute top-4 right-4 opacity-0 group-hover:opacity-100 transition-opacity">
                <Zap className="text-white" size={24} fill="white" />
              </div>
            </div>
          ))}
        </div>

        {/* CTA Section */}
        <div className="mt-16 text-center">
          <h3 className="text-2xl font-bold text-gray-900 dark:text-white mb-4">
            More Events Coming Soon!
          </h3>
          <p className="text-gray-600 dark:text-gray-400 mb-6">
            Check back regularly for new parliamentary events and initiatives
          </p>
          <a
            href="https://t.me/cwypsecretariat"
            target="_blank"
            rel="noopener noreferrer"
            className="btn btn-primary"
            style={{
              background: "linear-gradient(135deg, #22c55e 0%, #16a34a 100%)",
            }}
          >
            📢 Get Notified
          </a>
        </div>
      </div>
    </section>
  );
}
