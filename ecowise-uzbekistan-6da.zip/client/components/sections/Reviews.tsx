import { useState } from "react";
import { Star, Quote } from "lucide-react";

interface Review {
  id: number;
  name: string;
  role: string;
  institution: string;
  image: string;
  rating: number;
  event: string;
  region: string;
  text: string;
}

const reviews: Review[] = [
  {
    id: 1,
    name: "Aisha Uzbekova",
    role: "Student",
    institution: "School No. 5 Tashkent",
    image: "🎓",
    rating: 5,
    event: "Spring Parliamentary Summit",
    region: "Tashkent",
    text: "Commonwealth Youth Parliament completely changed how I think about democratic engagement. The summit was challenging, engaging, and truly impactful!",
  },
  {
    id: 2,
    name: "Karim Sultanov",
    role: "Educator",
    institution: "Secondary School Samarkand",
    image: "📚",
    rating: 5,
    event: "Youth Leadership Workshop",
    region: "Samarkand",
    text: "The workshops provided excellent resources and expertise. My students are now more passionate about parliamentary projects than ever!",
  },
  {
    id: 3,
    name: "Dilora Rashidova",
    role: "Student",
    institution: "School No. 12 Fergana",
    image: "🌟",
    rating: 5,
    event: "Regional Council Meeting",
    region: "Fergana",
    text: "Being part of Commonwealth Youth Parliament opened doors to leadership opportunities I never imagined. The community is incredibly supportive!",
  },
  {
    id: 4,
    name: "Javohir Nurmatov",
    role: "Student",
    institution: "School No. 8 Andijan",
    image: "🏆",
    rating: 5,
    event: "Democracy Day Celebration",
    region: "Andijan",
    text: "The hands-on experience of making a real difference in my community was unforgettable. Commonwealth Youth Parliament is truly empowering!",
  },
];

const filterOptions = ["All Reviews", "Participants", "Educators", "Partners"];

export default function Reviews() {
  const [filter, setFilter] = useState("All Reviews");

  return (
    <section id="reviews" className="section bg-gradient-reviews">
      <div className="container-main">
        {/* Section Header */}
        <div className="text-center mb-12">
          <h2 className="section-title text-primary">What Participants Say</h2>
          <p className="section-subtitle">
            Inspiring stories from Commonwealth Youth Parliament participants
          </p>
        </div>

        {/* Filters */}
        <div className="flex flex-wrap gap-3 justify-center mb-12">
          {filterOptions.map((option) => (
            <button
              key={option}
              onClick={() => setFilter(option)}
              className={`px-6 py-2 rounded-full font-medium transition-all duration-300 ${
                filter === option
                  ? "bg-primary text-white shadow-lg scale-105"
                  : "bg-white dark:bg-gray-800 text-gray-700 dark:text-gray-300 hover:shadow-md"
              }`}
            >
              {option}
            </button>
          ))}
        </div>

        {/* Reviews Grid */}
        <div className="grid md:grid-cols-2 gap-6 mb-12">
          {reviews.map((review, index) => (
            <div
              key={review.id}
              className="card-hover animate-fade-in-up"
              style={{ animationDelay: `${index * 0.1}s` }}
            >
              {/* Review Header */}
              <div className="flex items-start gap-4 mb-4">
                {/* Avatar - Emoji */}
                <div className="w-16 h-16 rounded-full bg-gradient-to-br from-primary/10 to-primary/5 dark:from-primary/20 dark:to-primary/10 flex items-center justify-center text-3xl flex-shrink-0">
                  {review.image}
                </div>

                {/* Header Info */}
                <div className="flex-1">
                  <h3 className="font-bold text-gray-900 dark:text-white">
                    {review.name}
                  </h3>
                  <p className="text-sm text-gray-600 dark:text-gray-400">
                    {review.role} • {review.institution}
                  </p>

                  {/* Rating */}
                  <div className="flex gap-1 mt-2">
                    {Array.from({ length: review.rating }).map((_, i) => (
                      <Star
                        key={i}
                        size={16}
                        className="fill-gold text-gold"
                      />
                    ))}
                  </div>
                </div>

                {/* Quote Icon */}
                <Quote
                  size={24}
                  className="text-primary/20 flex-shrink-0"
                />
              </div>

              {/* Review Text */}
              <p className="text-gray-700 dark:text-gray-300 mb-4 leading-relaxed">
                "{review.text}"
              </p>

              {/* Footer */}
              <div className="border-t border-gray-200 dark:border-gray-700 pt-4 flex items-center justify-between text-sm">
                <span className="badge badge-ocean">{review.event}</span>
                <span className="text-gray-500 dark:text-gray-400">
                  📍 {review.region}
                </span>
              </div>
            </div>
          ))}
        </div>

        {/* Secondary CTA */}
        <div className="card bg-gradient-to-r from-primary/10 to-emerald/10 text-center py-8 animate-fade-in-up">
          <h3 className="text-2xl font-bold text-gray-900 dark:text-white mb-4">
            Share Your Experience
          </h3>
          <p className="text-gray-600 dark:text-gray-400 mb-6 max-w-xl mx-auto">
            Have you participated in Commonwealth Youth Parliament? Tell us about your journey and inspire others!
          </p>
          <a
            href="https://t.me/cwypsecretariat"
            target="_blank"
            rel="noopener noreferrer"
            className="btn btn-primary inline-block"
          >
            ✍️ Submit Your Review
          </a>
        </div>
      </div>
    </section>
  );
}
