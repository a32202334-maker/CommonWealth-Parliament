import { useState } from "react";

interface RegionData {
  id: string;
  name: string;
  events: number;
  participants: number;
  ambassadors: number;
  x: number;
  y: number;
}

const regions: RegionData[] = [
  { id: "tashkent", name: "Tashkent", events: 2, participants: 45, ambassadors: 3, x: 626, y: 275 },
  { id: "samarkand", name: "Samarkand", events: 0, participants: 0, ambassadors: 1, x: 520, y: 340 },
  { id: "bukhara", name: "Bukhara", events: 1, participants: 15, ambassadors: 2, x: 410, y: 360 },
  { id: "fergana", name: "Fergana", events: 1, participants: 20, ambassadors: 1, x: 650, y: 240 },
  { id: "andijan", name: "Andijan", events: 2, participants: 30, ambassadors: 2, x: 720, y: 210 },
  { id: "jizzakh", name: "Jizzakh", events: 1, participants: 12, ambassadors: 1, x: 580, y: 320 },
  { id: "navoi", name: "Navoi", events: 0, participants: 0, ambassadors: 1, x: 450, y: 380 },
  { id: "surkhandarya", name: "Surkhondarya", events: 0, participants: 0, ambassadors: 0, x: 520, y: 420 },
  { id: "kashkadarya", name: "Kashkadarya", events: 1, participants: 18, ambassadors: 1, x: 480, y: 400 },
];

interface Tooltip {
  region: RegionData;
  x: number;
  y: number;
}

export default function UzbekistanMap() {
  const [tooltip, setTooltip] = useState<Tooltip | null>(null);
  const [hoveredRegion, setHoveredRegion] = useState<string | null>(null);

  const handleRegionHover = (region: RegionData, e: React.MouseEvent) => {
    const rect = (e.currentTarget as SVGPathElement).getBoundingClientRect();
    setTooltip({
      region,
      x: rect.x + rect.width / 2,
      y: rect.y - 10,
    });
    setHoveredRegion(region.id);
  };

  const handleMouseLeave = () => {
    setTooltip(null);
    setHoveredRegion(null);
  };

  return (
    <div className="relative w-full h-full">
      {/* SVG Map Container */}
      <div className="w-full h-[600px] bg-gradient-to-b from-blue-50 to-blue-100 dark:from-gray-800 dark:to-gray-900 rounded-2xl overflow-hidden flex items-center justify-center border-2 border-blue-200 dark:border-gray-700">
        <svg
          viewBox="0 0 1000 600"
          className="w-full h-full"
          preserveAspectRatio="xMidYMid meet"
        >
          {/* Simplified Uzbekistan Map Background */}
          <defs>
            <pattern id="dots" x="10" y="10" width="10" height="10" patternUnits="userSpaceOnUse">
              <circle cx="5" cy="5" r="1" fill="currentColor" fillOpacity="0.1" />
            </pattern>
          </defs>

          {/* Map Base */}
          <rect width="1000" height="600" fill="url(#dots)" />

          {/* Uzbekistan Outline (simplified) */}
          <path
            d="M 300 200 Q 400 150 550 170 L 750 180 Q 850 200 880 300 L 900 400 Q 850 450 750 470 L 550 480 Q 400 460 300 450 L 200 400 Q 150 350 200 250 Z"
            fill="rgba(163, 246, 193, 0.1)"
            stroke="#22c55e"
            strokeWidth="3"
          />

          {/* Region Markers */}
          {regions.map((region) => (
            <g key={region.id}>
              {/* Pin Icon */}
              <circle
                cx={region.x}
                cy={region.y}
                r="20"
                fill="#22c55e"
                stroke="white"
                strokeWidth="3"
                className={`cursor-pointer transition-all duration-300 ${
                  hoveredRegion === region.id ? "r-[30]" : ""
                }`}
                onMouseEnter={(e) => handleRegionHover(region, e as any)}
                onMouseLeave={handleMouseLeave}
                style={{
                  filter:
                    hoveredRegion === region.id
                      ? "drop-shadow(0 0 15px rgba(34, 197, 94, 0.8))"
                      : "drop-shadow(0 4px 12px rgba(34, 197, 94, 0.4))",
                }}
              />
              {/* Pin Pointer */}
              <path
                d={`M ${region.x},${region.y + 20} L ${region.x - 8},${region.y + 35} L ${region.x},${region.y + 40} L ${region.x + 8},${region.y + 35} Z`}
                fill="#22c55e"
                onMouseEnter={(e) => handleRegionHover(region, e as any)}
                onMouseLeave={handleMouseLeave}
              />
              {/* Region Label */}
              <text
                x={region.x}
                y={region.y - 30}
                textAnchor="middle"
                className="text-xs font-bold fill-gray-900 dark:fill-white pointer-events-none"
                fontSize="12"
              >
                {region.name}
              </text>
            </g>
          ))}
        </svg>
      </div>

      {/* Tooltip */}
      {tooltip && (
        <div
          className="fixed bg-white dark:bg-gray-800 rounded-2xl shadow-2xl p-4 border-2 border-blue-500 dark:border-blue-400 z-50 w-80 animate-scale-in"
          style={{
            left: `${tooltip.x}px`,
            top: `${tooltip.y}px`,
            transform: "translate(-50%, -100%)",
          }}
        >
          {/* Tooltip Header */}
          <div className="flex items-center gap-2 mb-3">
            <div className="w-3 h-3 bg-blue-500 rounded-full" />
            <h3 className="font-bold text-gray-900 dark:text-white text-lg">
              {tooltip.region.name}
            </h3>
          </div>

          {/* Tooltip Content */}
          <p className="text-sm text-gray-600 dark:text-gray-400 mb-4">
            {tooltip.region.events > 0
              ? `Hosting ecological competitions and events`
              : "Soon joining the EcoWise network"}
          </p>

          {/* Stats Grid */}
          <div className="grid grid-cols-3 gap-2">
            <div className="bg-blue-50 dark:bg-blue-900/30 rounded-lg p-2 text-center">
              <div className="text-xl font-bold text-blue-600 dark:text-blue-400">
                {tooltip.region.events}
              </div>
              <div className="text-xs text-gray-600 dark:text-gray-400">Events</div>
            </div>
            <div className="bg-emerald-50 dark:bg-emerald-900/30 rounded-lg p-2 text-center">
              <div className="text-xl font-bold text-emerald-600 dark:text-emerald-400">
                {tooltip.region.participants}
              </div>
              <div className="text-xs text-gray-600 dark:text-gray-400">Participants</div>
            </div>
            <div className="bg-purple-50 dark:bg-purple-900/30 rounded-lg p-2 text-center">
              <div className="text-xl font-bold text-purple-600 dark:text-purple-400">
                {tooltip.region.ambassadors}
              </div>
              <div className="text-xs text-gray-600 dark:text-gray-400">Ambassadors</div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
