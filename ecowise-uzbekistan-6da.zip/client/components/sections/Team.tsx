import { Linkedin, Instagram, Star } from "lucide-react";

interface TeamMember {
  id: number;
  name: string;
  role: string;
  image: string;
  socials?: {
    linkedin?: string;
    instagram?: string;
    email?: string;
  };
}

const mainTeamMembers: TeamMember[] = [
  {
    id: 1,
    name: "Alisher Yunusov",
    role: "Founder & Executive Director",
    image: "https://cdn.builder.io/api/v1/image/assets%2F5abc33fd419e48bbbfbf06bef23667f9%2F9b55480612f84936affa5a2917cbe97f?format=webp&width=400&height=400",
    socials: {
      linkedin: "https://www.linkedin.com/in/alisher-yunusov-47bba4351?utm_source=share_via&utm_content=profile&utm_medium=member_ios",
    },
  },
  {
    id: 2,
    name: "Dovudbek Abdugaffurov",
    role: "Expansion Manager",
    image: "https://cdn.builder.io/api/v1/image/assets%2F5abc33fd419e48bbbfbf06bef23667f9%2Fa3348503fb804cdf91d9f3dbc210d01b?format=webp&width=400&height=400",
    socials: {
      linkedin: "https://www.linkedin.com/in/dovudbek?utm_source=share_via&utm_content=profile&utm_medium=member_ios",
    },
  },
  {
    id: 3,
    name: "Abdulaziz Abdurakhimov",
    role: "Vice President",
    image: "https://cdn.builder.io/api/v1/image/assets%2F5abc33fd419e48bbbfbf06bef23667f9%2Fc0f0341da5b14b989f3197a1c5ebf690?format=webp&width=400&height=400",
    socials: {
      linkedin: "https://www.linkedin.com/in/abdulaziz-abdurakhimov-ba3a87383?utm_source=share_via&utm_content=profile&utm_medium=member_ios",
    },
  },
  {
    id: 4,
    name: "Saidamirhon Nimatullayev",
    role: "Finance Department Head",
    image: "https://cdn.builder.io/api/v1/image/assets%2F5abc33fd419e48bbbfbf06bef23667f9%2Fad403103c5e2466a99afc2eea801b468?format=webp&width=400&height=400",
    socials: {
      linkedin: "https://www.linkedin.com/in/saidamirkhon-nimatullaev-701446384?utm_source=share_via&utm_content=profile&utm_medium=member_ios",
    },
  },
];

const otherTeamMembers: (TeamMember & { region?: string })[] = [
  {
    id: 5,
    name: "Feruza",
    role: "Regional Ambassador",
    image: "👩‍💼",
    region: "Bukhara",
  },
  {
    id: 6,
    name: "Damirbek",
    role: "Regional Ambassador",
    image: "👨‍💼",
    region: "Samarkand",
  },
  {
    id: 7,
    name: "Dilyor",
    role: "Regional Ambassador",
    image: "👨‍💼",
    region: "Andijan",
  },
  {
    id: 8,
    name: "Shahzoda",
    role: "Regional Ambassador",
    image: "👩‍💼",
    region: "Khorezm",
  },
  {
    id: 9,
    name: "Sapura",
    role: "Regional Ambassador",
    image: "👩‍💼",
    region: "Nukus",
  },
  {
    id: 10,
    name: "Namajon",
    role: "Regional Ambassador",
    image: "👨‍💼",
    region: "Bukhara",
  },
  {
    id: 11,
    name: "Azimjon",
    role: "Regional Ambassador",
    image: "👨‍💼",
    region: "Tashkent",
  },
];

export default function Team() {
  return (
    <section id="team" className="section bg-gradient-team">
      <div className="container-main">
        {/* Section Header */}
        <div className="text-center mb-16">
          <h2 className="section-title text-primary">Our Leadership Team</h2>
          <p className="section-subtitle">
            Meet the dedicated leaders driving Commonwealth Youth Parliament's mission
          </p>
        </div>

        {/* Main Team Section */}
        <div className="mb-20">
          <h3 className="text-3xl font-bold text-gray-900 dark:text-white text-center mb-12">
            Core Leadership
          </h3>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {mainTeamMembers.map((member, index) => (
              <div
                key={member.id}
                className="card-hover text-center animate-fade-in-up group"
                style={{ animationDelay: `${index * 0.1}s` }}
              >
                {/* Image Container */}
                <div className="relative mb-6 rounded-2xl overflow-hidden h-64">
                  {member.image.startsWith('http') ? (
                    <img
                      src={member.image}
                      alt={member.name}
                      className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                    />
                  ) : (
                    <div className="w-full h-full bg-gradient-to-br from-primary/10 to-primary/5 dark:from-primary/20 dark:to-primary/10 flex items-center justify-center text-8xl">
                      {member.image}
                    </div>
                  )}

                  {/* Leadership Badge */}
                  <div className="absolute top-3 right-3 flex items-center gap-1 bg-primary text-white px-3 py-1 rounded-full text-sm font-bold">
                    <Star size={14} className="fill-current" />
                    Leader
                  </div>
                </div>

                {/* Content */}
                <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-1">
                  {member.name}
                </h3>
                <p className="text-primary font-semibold mb-4">{member.role}</p>

                {/* Social Links */}
                {member.socials && (
                  <div className="flex gap-3 justify-center border-t border-gray-200 dark:border-gray-700 pt-4">
                    {member.socials.linkedin && (
                      <a
                        href={member.socials.linkedin}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="w-10 h-10 rounded-lg bg-primary/10 hover:bg-primary/20 flex items-center justify-center text-primary transition-colors"
                      >
                        <Linkedin size={18} />
                      </a>
                    )}
                    {member.socials.instagram && (
                      <a
                        href={member.socials.instagram}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="w-10 h-10 rounded-lg bg-pink-500/10 hover:bg-pink-500/20 flex items-center justify-center text-pink-500 transition-colors"
                      >
                        <Instagram size={18} />
                      </a>
                    )}
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>

        {/* Regional Ambassadors Section */}
        <div className="mb-16">
          <h3 className="text-3xl font-bold text-gray-900 dark:text-white text-center mb-12">
            Regional Ambassadors
          </h3>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {otherTeamMembers.map((member, index) => (
              <div
                key={member.id}
                className="card-hover animate-fade-in-up"
                style={{ animationDelay: `${index * 0.05}s` }}
              >
                {/* Image Container - Emoji */}
                <div className="relative mb-4 rounded-xl overflow-hidden h-48 bg-gradient-to-br from-primary/10 to-primary/5 dark:from-primary/20 dark:to-primary/10 flex items-center justify-center">
                  <div className="text-6xl">{member.image}</div>
                </div>

                {/* Content */}
                <h3 className="text-lg font-bold text-gray-900 dark:text-white mb-1">
                  {member.name}
                </h3>
                <p className="text-sm text-primary font-medium">{member.role}</p>
                {(member as any).region && (
                  <p className="text-xs text-gray-500 dark:text-gray-400 mt-2">📍 {(member as any).region}</p>
                )}
              </div>
            ))}
          </div>
        </div>

        {/* Join CTA */}
        <div className="bg-white dark:bg-gray-800 rounded-3xl p-8 md:p-12 text-center">
          <h3 className="text-3xl font-bold text-gray-900 dark:text-white mb-4">
            Join Our Team
          </h3>
          <p className="text-gray-600 dark:text-gray-400 mb-6 max-w-2xl mx-auto">
            Are you passionate about youth empowerment and parliamentary engagement? We're always looking for dedicated team members to join our mission.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <a
              href="https://t.me/cwypsecretariat"
              target="_blank"
              rel="noopener noreferrer"
              className="btn btn-primary"
            >
              🤝 Join Our Team
            </a>
            <a
              href="https://t.me/cwypsecretariat"
              target="_blank"
              rel="noopener noreferrer"
              className="btn btn-outline"
            >
              🙋 Volunteer with Us
            </a>
          </div>
        </div>
      </div>
    </section>
  );
}
