export default function HeroAnimatedBackground() {
  return (
    <div className="absolute inset-0 z-0 overflow-hidden">
      {/* Animated Gradient Circles */}
      <div className="absolute top-0 left-0 w-96 h-96 bg-gradient-to-br from-red-500/25 to-transparent rounded-full blur-3xl animate-float"></div>
      <div
        className="absolute top-20 right-20 w-80 h-80 bg-gradient-to-br from-blue-500/25 to-transparent rounded-full blur-3xl animate-float-slow"
        style={{ animationDelay: "1s" }}
      ></div>
      <div
        className="absolute bottom-0 left-1/3 w-96 h-96 bg-gradient-to-br from-yellow-500/25 to-transparent rounded-full blur-3xl animate-float"
        style={{ animationDelay: "2s" }}
      ></div>
      <div
        className="absolute bottom-20 right-0 w-80 h-80 bg-gradient-to-br from-red-500/20 to-blue-500/20 rounded-full blur-3xl animate-float-slow"
        style={{ animationDelay: "1.5s" }}
      ></div>

      {/* Animated Grid Lines */}
      <svg className="absolute inset-0 w-full h-full opacity-5" preserveAspectRatio="none">
        <defs>
          <pattern id="gridPattern" width="50" height="50" patternUnits="userSpaceOnUse">
            <path d="M 50 0 L 0 0 0 50" fill="none" stroke="currentColor" strokeWidth="0.5" />
          </pattern>
          <linearGradient id="gradientLine" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="rgba(239, 68, 68, 0.4)" />
            <stop offset="25%" stopColor="rgba(59, 130, 246, 0.4)" />
            <stop offset="50%" stopColor="rgba(234, 179, 8, 0.4)" />
            <stop offset="75%" stopColor="rgba(239, 68, 68, 0.35)" />
            <stop offset="100%" stopColor="rgba(59, 130, 246, 0.4)" />
          </linearGradient>
        </defs>
        <rect width="100%" height="100%" fill="url(#gridPattern)" />
        <line x1="0%" y1="0%" x2="100%" y2="100%" stroke="url(#gradientLine)" strokeWidth="2" />
        <line x1="100%" y1="0%" x2="0%" y2="100%" stroke="url(#gradientLine)" strokeWidth="2" />
      </svg>

      {/* Animated Orbs */}
      <div className="absolute top-1/4 left-1/4 w-32 h-32 bg-gradient-to-br from-red-400 to-red-600 rounded-full blur-2xl opacity-25 animate-pulse" style={{ animationDuration: "4s" }}></div>
      <div className="absolute top-1/3 right-1/4 w-40 h-40 bg-gradient-to-br from-blue-400 to-blue-600 rounded-full blur-2xl opacity-25 animate-pulse" style={{ animationDuration: "5s", animationDelay: "0.5s" }}></div>
      <div className="absolute bottom-1/4 left-1/2 w-36 h-36 bg-gradient-to-br from-yellow-400 to-yellow-600 rounded-full blur-2xl opacity-25 animate-pulse" style={{ animationDuration: "6s", animationDelay: "1s" }}></div>
      <div className="absolute bottom-1/3 right-1/3 w-44 h-44 bg-gradient-to-br from-red-400 to-yellow-500 rounded-full blur-2xl opacity-20 animate-pulse" style={{ animationDuration: "5.5s", animationDelay: "0.75s" }}></div>

      {/* Shimmer Effect */}
      <div className="absolute inset-0 bg-gradient-to-t from-primary/5 via-transparent to-primary/5 opacity-50"></div>
    </div>
  );
}
