import { useState } from "react";

interface RegionData {
  id: string;
  name: string;
  events: number;
  participants: number;
  ambassadors: number;
  pinX: number;
  pinY: number;
}

const regions: RegionData[] = [
  { id: "karakalpakstan", name: "Karakalpakstan", events: 0, participants: 0, ambassadors: 1, pinX: 140, pinY: 140 },
  { id: "navoi", name: "Navoi Region", events: 0, participants: 0, ambassadors: 1, pinX: 280, pinY: 200 },
  { id: "bukhara", name: "Bukhara Region", events: 1, participants: 15, ambassadors: 1, pinX: 320, pinY: 260 },
  { id: "kashkadarya", name: "Kashkadarya Region", events: 1, participants: 18, ambassadors: 1, pinX: 380, pinY: 330 },
  { id: "surkhandarya", name: "Surkhondarya Region", events: 0, participants: 0, ambassadors: 0, pinX: 450, pinY: 380 },
  { id: "jizzakh", name: "Jizzakh Region", events: 1, participants: 12, ambassadors: 1, pinX: 350, pinY: 240 },
  { id: "samarkand", name: "Samarkand Region", events: 0, participants: 0, ambassadors: 1, pinX: 360, pinY: 180 },
  { id: "tashkent", name: "Tashkent Region", events: 1, participants: 25, ambassadors: 2, pinX: 420, pinY: 130 },
  { id: "tashkent-city", name: "Tashkent City", events: 2, participants: 45, ambassadors: 3, pinX: 440, pinY: 120 },
  { id: "namangan", name: "Namangan Region", events: 0, participants: 0, ambassadors: 1, pinX: 480, pinY: 100 },
  { id: "fergana", name: "Fergana Region", events: 1, participants: 20, ambassadors: 1, pinX: 520, pinY: 130 },
  { id: "andijan", name: "Andijan Region", events: 2, participants: 30, ambassadors: 2, pinX: 570, pinY: 110 },
];

interface Tooltip {
  region: RegionData;
  x: number;
  y: number;
}

export default function GeographicalUzbekistanMap() {
  const [tooltip, setTooltip] = useState<Tooltip | null>(null);
  const [hoveredRegion, setHoveredRegion] = useState<string | null>(null);

  const handlePinHover = (region: RegionData, e: React.MouseEvent<SVGGElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    setTooltip({
      region,
      x: rect.x + rect.width / 2,
      y: rect.y - 10,
    });
    setHoveredRegion(region.id);
  };

  const handleMouseLeave = () => {
    setTooltip(null);
    setHoveredRegion(null);
  };

  return (
    <div className="relative w-full h-full">
      {/* SVG Map Container */}
      <div className="w-full h-[600px] bg-gradient-to-b from-blue-50 to-blue-100 dark:from-gray-800 dark:to-gray-900 rounded-2xl overflow-hidden border-2 border-blue-200 dark:border-gray-700 flex items-center justify-center">
        <svg
          viewBox="0 0 650 450"
          className="w-full h-full"
          preserveAspectRatio="xMidYMid meet"
        >
          {/* Define gradients */}
          <defs>
            <linearGradient id="mapGradient" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#e0f2fe" />
              <stop offset="100%" stopColor="#bae6fd" />
            </linearGradient>
            <pattern id="mapPattern" x="20" y="20" width="20" height="20" patternUnits="userSpaceOnUse">
              <circle cx="10" cy="10" r="1" fill="currentColor" fillOpacity="0.06" />
            </pattern>
          </defs>

          {/* Background */}
          <rect width="650" height="450" fill="url(#mapGradient)" />
          <rect width="650" height="450" fill="url(#mapPattern)" />

          {/* UZBEKISTAN COUNTRY OUTLINE - More accurate geographical shape */}
          <path
            d="M 100 80 L 140 70 L 180 75 L 220 85 L 260 100 L 300 110 L 340 120 L 380 125 L 420 130 L 460 125 L 500 120 L 540 130 L 580 135 L 600 140 L 610 160 L 615 190 L 620 220 L 615 250 L 600 270 L 570 280 L 540 285 L 500 290 L 460 295 L 420 300 L 380 310 L 340 320 L 300 330 L 260 335 L 220 330 L 180 325 L 140 320 L 100 310 L 80 290 L 70 260 L 65 230 L 60 200 L 65 170 L 70 140 L 80 110 Z"
            fill="#c8e6c9"
            stroke="#22c55e"
            strokeWidth="3"
            opacity="0.9"
          />

          {/* REGION BOUNDARIES - Internal borders */}
          
          {/* Karakalpakstan boundary (left side) */}
          <path
            d="M 100 80 L 140 70 L 140 200 L 100 210 Z"
            fill="none"
            stroke="#22c55e"
            strokeWidth="1.5"
            opacity="0.6"
            strokeDasharray="4,4"
          />

          {/* Navoi and upper regions */}
          <path
            d="M 140 70 L 260 100 L 260 140 L 140 120 Z"
            fill="none"
            stroke="#22c55e"
            strokeWidth="1.5"
            opacity="0.6"
            strokeDasharray="4,4"
          />

          {/* Samarkand region */}
          <path
            d="M 260 100 L 340 120 L 360 180 L 300 160 Z"
            fill="none"
            stroke="#22c55e"
            strokeWidth="1.5"
            opacity="0.6"
            strokeDasharray="4,4"
          />

          {/* Tashkent Region */}
          <path
            d="M 340 120 L 420 130 L 420 160 L 360 155 Z"
            fill="none"
            stroke="#22c55e"
            strokeWidth="1.5"
            opacity="0.6"
            strokeDasharray="4,4"
          />

          {/* Fergana Valley (eastern region) */}
          <path
            d="M 460 125 L 580 135 L 580 180 L 500 170 L 460 160 Z"
            fill="none"
            stroke="#22c55e"
            strokeWidth="1.5"
            opacity="0.6"
            strokeDasharray="4,4"
          />

          {/* Bukhara region */}
          <path
            d="M 140 120 L 260 140 L 280 220 L 180 240 Z"
            fill="none"
            stroke="#22c55e"
            strokeWidth="1.5"
            opacity="0.6"
            strokeDasharray="4,4"
          />

          {/* Kashkadarya region */}
          <path
            d="M 260 140 L 360 180 L 380 270 L 300 260 Z"
            fill="none"
            stroke="#22c55e"
            strokeWidth="1.5"
            opacity="0.6"
            strokeDasharray="4,4"
          />

          {/* Surkhondarya region (southern) */}
          <path
            d="M 300 260 L 380 270 L 420 340 L 340 340 Z"
            fill="none"
            stroke="#22c55e"
            strokeWidth="1.5"
            opacity="0.6"
            strokeDasharray="4,4"
          />

          {/* LOCATION PINS WITH EMOJI ICONS */}
          {regions.map((region) => (
            <g
              key={region.id}
              onMouseEnter={(e) => handlePinHover(region, e)}
              onMouseLeave={handleMouseLeave}
              className="cursor-pointer"
            >
              {/* Pin Base - Outer circle */}
              <circle
                cx={region.pinX}
                cy={region.pinY}
                r="16"
                fill="#ffffff"
                stroke="#22c55e"
                strokeWidth="2.5"
                className="transition-all duration-300"
                style={{
                  filter: hoveredRegion === region.id ? "drop-shadow(0 0 10px rgba(34, 197, 94, 0.8))" : "drop-shadow(0 2px 6px rgba(0, 0, 0, 0.15))",
                  transform: hoveredRegion === region.id ? "scale(1.25)" : "scale(1)",
                }}
              />

              {/* Pin Icon */}
              <text
                x={region.pinX}
                y={region.pinY + 5}
                textAnchor="middle"
                className="font-bold select-none pointer-events-none"
                fontSize="18"
              >
                📍
              </text>

              {/* Pin Pointer */}
              <path
                d={`M ${region.pinX},${region.pinY + 16} L ${region.pinX - 5},${region.pinY + 24} L ${region.pinX},${region.pinY + 28} L ${region.pinX + 5},${region.pinY + 24} Z`}
                fill="#ffffff"
                stroke="#22c55e"
                strokeWidth="1.5"
              />
            </g>
          ))}

          {/* REGION LABELS */}
          <text x="110" y="145" textAnchor="middle" className="text-xs font-bold fill-gray-800 pointer-events-none" fontSize="9">
            Karakalpakstan
          </text>
          <text x="260" y="115" textAnchor="middle" className="text-xs font-bold fill-gray-800 pointer-events-none" fontSize="9">
            Navoi
          </text>
          <text x="360" y="165" textAnchor="middle" className="text-xs font-bold fill-gray-800 pointer-events-none" fontSize="9">
            Samarkand
          </text>
          <text x="200" y="210" textAnchor="middle" className="text-xs font-bold fill-gray-800 pointer-events-none" fontSize="9">
            Bukhara
          </text>
          <text x="320" y="280" textAnchor="middle" className="text-xs font-bold fill-gray-800 pointer-events-none" fontSize="9">
            Kashkadarya
          </text>
          <text x="420" y="320" textAnchor="middle" className="text-xs font-bold fill-gray-800 pointer-events-none" fontSize="9">
            Surkhondarya
          </text>
          <text x="390" y="150" textAnchor="middle" className="text-xs font-bold fill-gray-800 pointer-events-none" fontSize="9">
            Tashkent Reg.
          </text>
          <text x="520" y="115" textAnchor="middle" className="text-xs font-bold fill-gray-800 pointer-events-none" fontSize="9">
            Fergana Valley
          </text>
        </svg>
      </div>

      {/* Tooltip */}
      {tooltip && (
        <div
          className="fixed bg-white dark:bg-gray-800 rounded-2xl shadow-2xl p-4 border-2 border-emerald-500 dark:border-emerald-400 z-50 w-80 animate-scale-in"
          style={{
            left: `${tooltip.x}px`,
            top: `${tooltip.y}px`,
            transform: "translate(-50%, -100%)",
          }}
        >
          {/* Tooltip Header */}
          <div className="flex items-center gap-2 mb-3">
            <div className="w-3 h-3 bg-emerald-500 rounded-full" />
            <h3 className="font-bold text-gray-900 dark:text-white text-lg">
              {tooltip.region.name}
            </h3>
          </div>

          {/* Tooltip Content */}
          <p className="text-sm text-gray-600 dark:text-gray-400 mb-4">
            {tooltip.region.events > 0
              ? `${tooltip.region.events} ecological competition${tooltip.region.events > 1 ? "s" : ""}`
              : "Joining EcoWise soon"}
          </p>

          {/* Stats Grid */}
          <div className="grid grid-cols-3 gap-2">
            <div className="bg-emerald-50 dark:bg-emerald-900/30 rounded-lg p-2 text-center">
              <div className="text-xl font-bold text-emerald-600 dark:text-emerald-400">
                {tooltip.region.events}
              </div>
              <div className="text-xs text-gray-600 dark:text-gray-400">Events</div>
            </div>
            <div className="bg-blue-50 dark:bg-blue-900/30 rounded-lg p-2 text-center">
              <div className="text-xl font-bold text-blue-600 dark:text-blue-400">
                {tooltip.region.participants}
              </div>
              <div className="text-xs text-gray-600 dark:text-gray-400">Participants</div>
            </div>
            <div className="bg-purple-50 dark:bg-purple-900/30 rounded-lg p-2 text-center">
              <div className="text-xl font-bold text-purple-600 dark:text-purple-400">
                {tooltip.region.ambassadors}
              </div>
              <div className="text-xs text-gray-600 dark:text-gray-400">Ambassadors</div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
