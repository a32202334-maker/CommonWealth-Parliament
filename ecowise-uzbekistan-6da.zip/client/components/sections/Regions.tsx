import RegionsWithCards from "./RegionsWithCards";

export default function Regions() {
  return <RegionsWithCards />;
}
