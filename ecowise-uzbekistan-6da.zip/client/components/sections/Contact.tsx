import { Mail, Phone, MapPin, Instagram, Linkedin, Send } from "lucide-react";

export default function Contact() {
  const involvementOptions = [
    {
      icon: "🏆",
      title: "Participate in Competitions",
      description: "Join our case competitions and develop innovative solutions to real parliamentary challenges.",
      buttonText: "Register Now",
      link: "https://t.me/cwypsecretariat",
      buttonClass: "btn btn-primary",
      external: true,
    },
    {
      icon: "🌱",
      title: "Volunteer",
      description: "Support our events and initiatives while gaining valuable experience in environmental advocacy.",
      buttonText: "Volunteer",
      link: "https://t.me/cwypsecretariat",
      buttonClass: "btn btn-success",
      external: true,
    },
    {
      icon: "🤝",
      title: "Partner with Us",
      description: "Organizations looking to support environmental education and student development.",
      buttonText: "Become Partner",
      link: "https://t.me/cwypsecretariat",
      buttonClass: "btn btn-primary",
      external: true,
    },
  ];

  const socialLinks = [
    {
      name: "Instagram",
      icon: Instagram,
      link: "https://instagram.com/cwparliament",
      label: "@cwparliament",
      bgColor: "bg-pink-500/10",
      textColor: "text-pink-500",
    },
    {
      name: "Telegram",
      icon: Send,
      link: "https://t.me/cwypsecretariat",
      label: "@cwypsecretariat",
      bgColor: "bg-sky-500/10",
      textColor: "text-sky-500",
    },
  ];

  return (
    <section id="contact" className="section bg-white dark:bg-gray-900">
      <div className="container-main">
        {/* Section Header */}
        <div className="text-center mb-16">
          <h2 className="section-title text-primary">Get Involved</h2>
          <p className="section-subtitle">
            Join us in making a difference. There are many ways to be part of the EcoWise journey.
          </p>
        </div>

        {/* Involvement Cards */}
        <div className="grid md:grid-cols-3 gap-6 mb-16">
          {involvementOptions.map((option, index) => (
            <div
              key={index}
              className="card-hover animate-fade-in-up"
              style={{ animationDelay: `${index * 0.1}s` }}
            >
              {/* Icon */}
              <div className="text-6xl mb-6 text-center">{option.icon}</div>

              {/* Content */}
              <h3 className="text-2xl font-bold text-gray-900 dark:text-white mb-3">
                {option.title}
              </h3>
              <p className="text-gray-600 dark:text-gray-400 mb-8 leading-relaxed">
                {option.description}
              </p>

              {/* Button */}
              {option.external ? (
                <a
                  href={option.link}
                  target="_blank"
                  rel="noopener noreferrer"
                  className={`${option.buttonClass} w-full text-center block`}
                >
                  {option.buttonText}
                </a>
              ) : (
                <a href={option.link} className={`${option.buttonClass} w-full text-center block`}>
                  {option.buttonText}
                </a>
              )}
            </div>
          ))}
        </div>

        {/* Contact Information Section */}
        <div className="rounded-3xl p-8 md:p-12" style={{background: "linear-gradient(135deg, rgba(34, 197, 94, 0.08) 0%, rgba(234, 179, 8, 0.06) 25%, rgba(239, 68, 68, 0.06) 50%, rgba(59, 130, 246, 0.08) 75%, rgba(34, 197, 94, 0.08) 100%)"}}>
          <div className="grid md:grid-cols-2 gap-12">
            {/* Left - Contact Details */}
            <div className="animate-fade-in-up">
              <h3 className="text-2xl font-bold text-gray-900 dark:text-white mb-8">
                Contact Information
              </h3>

              <div className="space-y-6">
                {/* Location */}
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 bg-primary/10 dark:bg-primary/20 rounded-lg flex items-center justify-center flex-shrink-0">
                    <MapPin className="text-primary" size={24} />
                  </div>
                  <div>
                    <p className="font-semibold text-gray-900 dark:text-white">Location</p>
                    <p className="text-gray-600 dark:text-gray-400">Tashkent, Uzbekistan</p>
                  </div>
                </div>
              </div>
            </div>

            {/* Right - Social Links */}
            <div className="animate-fade-in-up" style={{ animationDelay: "0.1s" }}>
              <h3 className="text-2xl font-bold text-gray-900 dark:text-white mb-8">
                Connect with Us
              </h3>

              <div className="space-y-3">
                {socialLinks.map((social) => {
                  const Icon = social.icon;
                  return (
                    <a
                      key={social.name}
                      href={social.link}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex items-center gap-4 p-4 bg-white dark:bg-gray-800 rounded-xl hover:shadow-md hover:-translate-y-1 transition-all group"
                    >
                      <div className={`w-12 h-12 ${social.bgColor} dark:${social.bgColor} rounded-lg flex items-center justify-center flex-shrink-0 group-hover:scale-110 transition-transform`}>
                        <Icon className={`${social.textColor} dark:${social.textColor}`} size={24} />
                      </div>
                      <div className="flex-1">
                        <p className="font-semibold text-gray-900 dark:text-white text-sm">
                          {social.name}
                        </p>
                        <p className="text-gray-600 dark:text-gray-400 text-sm">
                          {social.label}
                        </p>
                      </div>
                    </a>
                  );
                })}
              </div>
            </div>
          </div>
        </div>

        {/* Newsletter Signup */}
        <div className="mt-12 bg-gradient-to-r from-primary to-primary-light dark:from-primary dark:to-emerald rounded-3xl p-8 md:p-12 text-white text-center animate-fade-in-up">
          <h3 className="text-2xl font-bold mb-4">Join Our Community</h3>
          <p className="mb-6 opacity-90 max-w-xl mx-auto">
            Connect with Commonwealth Youth Parliament for the latest news, events, and opportunities.
          </p>
          <div className="flex flex-col sm:flex-row gap-3 justify-center">
            <a
              href="https://t.me/cwypsecretariat"
              target="_blank"
              rel="noopener noreferrer"
              className="px-8 py-3 bg-white text-primary rounded-xl font-bold hover:bg-gray-100 transition-colors inline-block"
            >
              Join on Telegram
            </a>
          </div>
        </div>
      </div>
    </section>
  );
}
