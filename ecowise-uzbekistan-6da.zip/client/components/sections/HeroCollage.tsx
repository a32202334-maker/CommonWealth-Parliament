export default function HeroCollage() {
  // Sample image URLs - in production these would be actual images
  const collageImages = [
    "https://images.unsplash.com/photo-1441974231531-c6227db76b6e?w=400&h=300&fit=crop",
    "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=300&h=400&fit=crop",
    "https://images.unsplash.com/photo-1559027615-cd2628902d4a?w=400&h=300&fit=crop",
    "https://images.unsplash.com/photo-1454165804606-c3d57bc86b40?w=300&h=300&fit=crop",
    "https://images.unsplash.com/photo-1504384308090-c894fdcc538d?w=400&h=300&fit=crop",
    "https://images.unsplash.com/photo-1511379938547-c1f69b13d835?w=300&h=400&fit=crop",
    "https://images.unsplash.com/photo-1518531933037-91b2f5f9cc6f?w=400&h=300&fit=crop",
    "https://images.unsplash.com/photo-1517694712202-14dd9538aa97?w=300&h=300&fit=crop",
    "https://images.unsplash.com/photo-1505142468610-359e7d316be0?w=400&h=300&fit=crop",
    "https://images.unsplash.com/photo-1470225620780-dba8ba36b745?w=300&h=400&fit=crop",
    "https://images.unsplash.com/photo-1476514525535-07fb3b4ae5f1?w=400&h=300&fit=crop",
    "https://images.unsplash.com/photo-1441974231531-c6227db76b6e?w=300&h=300&fit=crop",
  ];

  return (
    <div className="absolute inset-0 z-0 overflow-hidden">
      {/* Grid Collage */}
      <div className="grid grid-cols-6 grid-rows-4 gap-1 h-full w-full p-2">
        {collageImages.map((image, index) => (
          <div
            key={index}
            className="rounded-lg overflow-hidden hover:scale-105 transition-transform duration-500"
            style={{
              gridColumn: index % 3 === 0 ? "span 2" : "span 1",
              gridRow: index % 4 === 0 ? "span 2" : "span 1",
            }}
          >
            <img
              src={image}
              alt={`Collage ${index}`}
              className="w-full h-full object-cover"
            />
          </div>
        ))}
      </div>

      {/* Overlay Gradient */}
      <div className="absolute inset-0 bg-gradient-to-br from-primary/25 via-primary/15 to-primary/25" />

      {/* Additional Vignette */}
      <div className="absolute inset-0 bg-gradient-radial from-transparent to-primary/20" />
    </div>
  );
}
