import { useState } from "react";
import { MapPin, Users, Calendar } from "lucide-react";

interface Region {
  id: string;
  name: string;
  description: string;
  events: number;
  participants: number;
  ambassadors: number;
  color: string;
  icon: string;
  landmark?: string;
}

const initialRegions: Region[] = [
  {
    id: "tashkent",
    name: "Tashkent City",
    description: "Capital region with active youth programs",
    events: 1,
    participants: 150,
    ambassadors: 8,
    color: "from-blue-500 to-blue-600",
    icon: "🏛️",
    landmark: "https://cdn.builder.io/api/v1/image/assets%2F5abc33fd419e48bbbfbf06bef23667f9%2Ff22372fd563c469f815a88d70d10999b?format=webp",
  },
  {
    id: "samarkand",
    name: "Samarkand Region",
    description: "Historical and cultural hub",
    events: 1,
    participants: 130,
    ambassadors: 4,
    color: "from-orange-500 to-orange-600",
    icon: "🏰",
    landmark: "https://cdn.builder.io/api/v1/image/assets%2F5abc33fd419e48bbbfbf06bef23667f9%2F7b9b32908cf44a5894ee5620b3f729f3?format=webp",
  },
  {
    id: "bukhara",
    name: "Bukhara Region",
    description: "Growing parliamentary engagement",
    events: 1,
    participants: 110,
    ambassadors: 3,
    color: "from-green-500 to-green-600",
    icon: "🌳",
    landmark: "https://cdn.builder.io/api/v1/image/assets%2F5abc33fd419e48bbbfbf06bef23667f9%2F6efd689bfb5b44f59dc51179aed580c8?format=webp",
  },
  {
    id: "fergana",
    name: "Fergana Valley",
    description: "Eastern youth center",
    events: 1,
    participants: 115,
    ambassadors: 5,
    color: "from-purple-500 to-purple-600",
    icon: "🌸",
    landmark: "https://cdn.builder.io/api/v1/image/assets%2F5abc33fd419e48bbbfbf06bef23667f9%2F0ae8c07adada46ce8a7432339dd21a48?format=webp",
  },
  {
    id: "navoi",
    name: "Navoi Region",
    description: "Industrial development zone",
    events: 1,
    participants: 90,
    ambassadors: 2,
    color: "from-red-500 to-red-600",
    icon: "⚙️",
    landmark: "https://cdn.builder.io/api/v1/image/assets%2F5abc33fd419e48bbbfbf06bef23667f9%2F8e24cd11188d4370b033f7590c48e381?format=webp",
  },
  {
    id: "kashkadarya",
    name: "Kashkadarya",
    description: "Rising parliamentary movement",
    events: 1,
    participants: 35,
    ambassadors: 4,
    color: "from-pink-500 to-pink-600",
    icon: "🎯",
    landmark: "https://cdn.builder.io/api/v1/image/assets%2F5abc33fd419e48bbbfbf06bef23667f9%2F1e8ad0df46e446058c0bf032df6faf10?format=webp",
  },
  {
    id: "nukus",
    name: "Nukus",
    description: "Karakalpakstan's capital",
    events: 1,
    participants: 20,
    ambassadors: 3,
    color: "from-teal-500 to-teal-600",
    icon: "🏛️",
    landmark: "https://cdn.builder.io/api/v1/image/assets%2F5abc33fd419e48bbbfbf06bef23667f9%2F51d9a7dd60a74214af6061b2aa9ab899?format=webp",
  },
];

export default function RegionsWithCards() {
  const [regions, setRegions] = useState(initialRegions);
  const [selectedRegion, setSelectedRegion] = useState<Region | null>(null);

  return (
    <section id="regions" className="section bg-gradient-to-b from-white via-blue-50 to-white dark:from-gray-900 dark:via-gray-800 dark:to-gray-900">
      <div className="container-main">
        {/* Section Header */}
        <div className="text-center mb-16">
          <h2 className="section-title text-primary">Regional Presence</h2>
          <p className="section-subtitle">
            Commonwealth Youth Parliament operates across multiple regions. Click any region to learn more.
          </p>
        </div>

        {/* Region Cards Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 mb-12">
          {regions.map((region, index) => (
            <button
              key={region.id}
              onClick={() => setSelectedRegion(region)}
              className={`group relative overflow-hidden rounded-2xl p-8 text-left transition-all duration-300 hover:shadow-2xl hover:-translate-y-2 animate-fade-in-up cursor-pointer border-2 border-transparent hover:border-primary`}
              style={{ animationDelay: `${index * 0.1}s` }}
            >
              {/* Gradient Background */}
              <div className={`absolute inset-0 bg-gradient-to-br ${region.color} opacity-0 group-hover:opacity-10 dark:group-hover:opacity-20 transition-opacity`} />

              {/* Landmark Image Background */}
              {region.landmark && (
                <div className="absolute inset-0 opacity-20 group-hover:opacity-40 transition-opacity">
                  <img src={region.landmark} alt={region.name} className="w-full h-full object-cover" />
                </div>
              )}

              {/* Card Content */}
              <div className="relative z-10">
                {/* Icon & Title */}
                <div className="flex items-start justify-between mb-4">
                  <div className="text-4xl">{region.icon}</div>
                  <div className={`w-10 h-10 rounded-full bg-gradient-to-br ${region.color} opacity-20 group-hover:opacity-100 transition-all`} />
                </div>

                {/* Title */}
                <h3 className="text-2xl font-bold text-gray-900 dark:text-white mb-2">
                  {region.name}
                </h3>

                {/* Description */}
                <p className="text-gray-600 dark:text-gray-400 mb-6 text-sm leading-relaxed">
                  {region.description}
                </p>

                {/* Stats Row - WITHOUT Events */}
                <div className="flex gap-4 pt-4 border-t border-gray-200 dark:border-gray-700">
                  <div className="flex-1">
                    <p className="text-xs text-gray-500 dark:text-gray-400 uppercase font-semibold">Members</p>
                    <p className={`text-lg font-bold bg-gradient-to-r ${region.color} bg-clip-text text-transparent`}>
                      {region.participants}
                    </p>
                  </div>
                  <div className="flex-1">
                    <p className="text-xs text-gray-500 dark:text-gray-400 uppercase font-semibold">Leaders</p>
                    <p className={`text-lg font-bold bg-gradient-to-r ${region.color} bg-clip-text text-transparent`}>
                      {region.ambassadors}
                    </p>
                  </div>
                </div>
              </div>
            </button>
          ))}
        </div>

        {/* Region Details Modal */}
        {selectedRegion && (
          <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
            <div className="bg-white dark:bg-gray-800 rounded-3xl max-w-2xl w-full p-8 animate-scale-in max-h-[90vh] overflow-y-auto">
              {/* Header */}
              <div className="flex items-start justify-between mb-6">
                <div className="flex items-center gap-4">
                  <div className="text-5xl">{selectedRegion.icon}</div>
                  <div>
                    <h2 className="text-3xl font-bold text-gray-900 dark:text-white">
                      {selectedRegion.name}
                    </h2>
                    <p className="text-gray-600 dark:text-gray-400 mt-1">
                      {selectedRegion.description}
                    </p>
                  </div>
                </div>
                <button
                  onClick={() => setSelectedRegion(null)}
                  className="text-2xl text-gray-400 hover:text-gray-900 dark:hover:text-white transition-colors"
                >
                  ×
                </button>
              </div>

              {/* Stats Grid */}
              <div className="grid grid-cols-3 gap-4 mb-8">
                <div className={`bg-gradient-to-br ${selectedRegion.color} rounded-2xl p-6 text-white`}>
                  <Calendar size={24} className="mb-2 opacity-80" />
                  <p className="text-sm font-semibold opacity-80">Events Held</p>
                  <p className="text-4xl font-bold">{selectedRegion.events}</p>
                </div>
                <div className={`bg-gradient-to-br ${selectedRegion.color} rounded-2xl p-6 text-white`}>
                  <Users size={24} className="mb-2 opacity-80" />
                  <p className="text-sm font-semibold opacity-80">Active Members</p>
                  <p className="text-4xl font-bold">{selectedRegion.participants}</p>
                </div>
                <div className={`bg-gradient-to-br ${selectedRegion.color} rounded-2xl p-6 text-white`}>
                  <MapPin size={24} className="mb-2 opacity-80" />
                  <p className="text-sm font-semibold opacity-80">Regional Leaders</p>
                  <p className="text-4xl font-bold">{selectedRegion.ambassadors}</p>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex gap-4">
                <a
                  href="https://t.me/cwypsecretariat"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex-1 btn btn-primary text-center"
                >
                  Join {selectedRegion.name}
                </a>
                <button
                  onClick={() => setSelectedRegion(null)}
                  className="flex-1 btn btn-outline"
                >
                  Close
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Stats Summary */}
        <div className="bg-gradient-to-r from-primary/5 to-emerald/5 dark:from-gray-800 dark:to-gray-800 rounded-3xl p-12 text-center">
          <h3 className="text-2xl font-bold text-gray-900 dark:text-white mb-8">Our Reach</h3>
          <div className="grid md:grid-cols-3 gap-8">
            <div className="animate-fade-in-up">
              <p className="text-5xl font-bold text-gradient-green mb-2">
                {regions.reduce((sum, r) => sum + r.events, 0)}
              </p>
              <p className="text-gray-600 dark:text-gray-400">Parliamentary Events</p>
            </div>
            <div className="animate-fade-in-up" style={{ animationDelay: "0.1s" }}>
              <p className="text-5xl font-bold text-gradient-ocean mb-2">
                {regions.reduce((sum, r) => sum + r.participants, 0)}
              </p>
              <p className="text-gray-600 dark:text-gray-400">Active Members</p>
            </div>
            <div className="animate-fade-in-up" style={{ animationDelay: "0.2s" }}>
              <p className="text-5xl font-bold text-gradient-blue mb-2">
                {regions.length}
              </p>
              <p className="text-gray-600 dark:text-gray-400">Regions Covered</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
