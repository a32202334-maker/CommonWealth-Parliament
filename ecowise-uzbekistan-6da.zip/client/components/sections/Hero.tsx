import { ArrowDown } from "lucide-react";
import HeroAnimatedBackground from "./HeroAnimatedBackground";
import HeroStats from "./HeroStats";

export default function Hero() {
  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    element?.scrollIntoView({ behavior: "smooth" });
  };

  return (
    <section id="hero" className="relative min-h-screen flex flex-col justify-center items-center pt-20 overflow-hidden">
      {/* Animated Background */}
      <HeroAnimatedBackground />

      {/* Floating Court/Parliament Icons */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden z-10">
        <div className="absolute top-10 left-10 text-4xl animate-float">⚖️</div>
        <div className="absolute top-32 right-20 text-3xl animate-float-slow" style={{ animationDelay: "0.5s" }}>
          🏛️
        </div>
        <div className="absolute bottom-32 left-20 text-3xl animate-float" style={{ animationDelay: "1s" }}>
          📜
        </div>
        <div className="absolute bottom-20 right-32 text-4xl animate-float-slow" style={{ animationDelay: "1.5s" }}>
          ⚔️
        </div>
      </div>

      {/* Content Card */}
      <div className="relative z-20 container-main max-w-3xl mx-auto px-4">
        <div className="glass rounded-3xl p-8 md:p-12 text-center animate-fade-in-up">
          {/* Title */}
          <h1 className="text-4xl sm:text-5xl md:text-6xl font-bold text-gray-900 dark:text-white mb-4 text-balance">
            Empowering Youth in
            <span className="text-gradient-blue ml-2">Parliamentary Democracy</span>
          </h1>

          {/* Subtitle */}
          <p className="text-lg md:text-xl text-gray-600 dark:text-gray-300 mb-8 max-w-2xl mx-auto text-balance">
            Commonwealth Youth Parliament is a youth-led initiative dedicated to developing the next generation of parliamentary leaders. Together, we're building a stronger democratic future.
          </p>

          {/* CTA Buttons */}
          <div className="flex flex-col sm:flex-row gap-4 justify-center mb-8">
            <button
              onClick={() => scrollToSection("about")}
              className="btn btn-success group"
            >
              <span>Learn About Us</span>
              <span className="group-hover:translate-y-1 transition-transform">📚</span>
            </button>
            <a
              href="https://t.me/cwypsecretariat"
              target="_blank"
              rel="noopener noreferrer"
              className="btn btn-secondary"
            >
              Join on Telegram
            </a>
          </div>

          {/* Stats */}
          <HeroStats />
        </div>
      </div>

      {/* Scroll Indicator */}
      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 z-20 animate-bounce">
        <button
          onClick={() => scrollToSection("about")}
          className="flex flex-col items-center gap-2 text-gray-700 dark:text-gray-300 hover:text-primary transition-colors"
        >
          <span className="text-sm font-semibold">Explore</span>
          <ArrowDown size={20} />
        </button>
      </div>
    </section>
  );
}
