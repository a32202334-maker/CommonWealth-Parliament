import { useState } from "react";

interface RegionData {
  id: string;
  name: string;
  events: number;
  participants: number;
  ambassadors: number;
}

const regions: RegionData[] = [
  { id: "tashkent-city", name: "Tashkent City", events: 2, participants: 45, ambassadors: 3 },
  { id: "tashkent", name: "Tashkent Region", events: 1, participants: 25, ambassadors: 2 },
  { id: "fergana", name: "Fergana Region", events: 1, participants: 20, ambassadors: 1 },
  { id: "andijan", name: "Andijan Region", events: 2, participants: 30, ambassadors: 2 },
  { id: "namangan", name: "Namangan Region", events: 0, participants: 0, ambassadors: 1 },
  { id: "samarkand", name: "Samarkand Region", events: 0, participants: 0, ambassadors: 1 },
  { id: "bukhara", name: "Bukhara Region", events: 1, participants: 15, ambassadors: 1 },
  { id: "navoi", name: "Navoi Region", events: 0, participants: 0, ambassadors: 1 },
  { id: "kashkadarya", name: "Kashkadarya Region", events: 1, participants: 18, ambassadors: 1 },
  { id: "surkhandarya", name: "Surkhondarya Region", events: 0, participants: 0, ambassadors: 0 },
  { id: "jizzakh", name: "Jizzakh Region", events: 1, participants: 12, ambassadors: 1 },
  { id: "karakalpakstan", name: "Karakalpakstan", events: 0, participants: 0, ambassadors: 1 },
];

interface Tooltip {
  region: RegionData;
  x: number;
  y: number;
}

export default function RealisticUzbekistanMap() {
  const [tooltip, setTooltip] = useState<Tooltip | null>(null);
  const [hoveredRegion, setHoveredRegion] = useState<string | null>(null);

  const handleRegionHover = (region: RegionData, e: React.MouseEvent<SVGPathElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    setTooltip({
      region,
      x: rect.x + rect.width / 2,
      y: rect.y - 10,
    });
    setHoveredRegion(region.id);
  };

  const handleMouseLeave = () => {
    setTooltip(null);
    setHoveredRegion(null);
  };

  return (
    <div className="relative w-full h-full">
      {/* SVG Map Container */}
      <div className="w-full h-[600px] bg-gradient-to-b from-blue-50 to-blue-100 dark:from-gray-800 dark:to-gray-900 rounded-2xl overflow-hidden border-2 border-blue-200 dark:border-gray-700 flex items-center justify-center">
        <svg
          viewBox="0 0 1200 900"
          className="w-full h-full"
          preserveAspectRatio="xMidYMid meet"
        >
          {/* Define gradients */}
          <defs>
            <linearGradient id="waterGradient" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#e0f2fe" />
              <stop offset="100%" stopColor="#bae6fd" />
            </linearGradient>
            <pattern id="dots" x="20" y="20" width="20" height="20" patternUnits="userSpaceOnUse">
              <circle cx="10" cy="10" r="1.5" fill="currentColor" fillOpacity="0.08" />
            </pattern>
          </defs>

          {/* Background */}
          <rect width="1200" height="900" fill="url(#waterGradient)" />
          <rect width="1200" height="900" fill="url(#dots)" />

          {/* Karakalpakstan - Top Left */}
          <path
            d="M 50 50 L 350 80 L 380 200 L 300 300 L 100 280 Z"
            fill={hoveredRegion === "karakalpakstan" ? "#fbbf24" : "#c8e6c9"}
            stroke="#22c55e"
            strokeWidth="2.5"
            className="cursor-pointer transition-all duration-300 hover:brightness-110"
            onMouseEnter={(e) => handleRegionHover(regions[11], e)}
            onMouseLeave={handleMouseLeave}
          />

          {/* Navoi - Top Center */}
          <path
            d="M 350 80 L 580 100 L 600 180 L 450 200 L 380 200 Z"
            fill={hoveredRegion === "navoi" ? "#fbbf24" : "#c8e6c9"}
            stroke="#22c55e"
            strokeWidth="2.5"
            className="cursor-pointer transition-all duration-300 hover:brightness-110"
            onMouseEnter={(e) => handleRegionHover(regions[7], e)}
            onMouseLeave={handleMouseLeave}
          />

          {/* Tashkent Region - Top Right */}
          <path
            d="M 580 100 L 750 110 L 780 200 L 600 180 Z"
            fill={hoveredRegion === "tashkent" ? "#fbbf24" : "#c8e6c9"}
            stroke="#22c55e"
            strokeWidth="2.5"
            className="cursor-pointer transition-all duration-300 hover:brightness-110"
            onMouseEnter={(e) => handleRegionHover(regions[1], e)}
            onMouseLeave={handleMouseLeave}
          />

          {/* Tashkent City - Northeast */}
          <circle
            cx="795"
            cy="165"
            r="25"
            fill={hoveredRegion === "tashkent-city" ? "#fbbf24" : "#4ade80"}
            stroke="#22c55e"
            strokeWidth="3"
            className="cursor-pointer transition-all duration-300 hover:brightness-110"
            onMouseEnter={(e) => handleRegionHover(regions[0], e)}
            onMouseLeave={handleMouseLeave}
          />

          {/* Namangan - East */}
          <path
            d="M 750 110 L 900 120 L 920 250 L 780 200 Z"
            fill={hoveredRegion === "namangan" ? "#fbbf24" : "#c8e6c9"}
            stroke="#22c55e"
            strokeWidth="2.5"
            className="cursor-pointer transition-all duration-300 hover:brightness-110"
            onMouseEnter={(e) => handleRegionHover(regions[4], e)}
            onMouseLeave={handleMouseLeave}
          />

          {/* Fergana - East Center */}
          <path
            d="M 900 120 L 1000 150 L 1050 280 L 920 250 Z"
            fill={hoveredRegion === "fergana" ? "#fbbf24" : "#c8e6c9"}
            stroke="#22c55e"
            strokeWidth="2.5"
            className="cursor-pointer transition-all duration-300 hover:brightness-110"
            onMouseEnter={(e) => handleRegionHover(regions[2], e)}
            onMouseLeave={handleMouseLeave}
          />

          {/* Andijan - East Bottom */}
          <path
            d="M 1000 150 L 1100 180 L 1080 320 L 1050 280 Z"
            fill={hoveredRegion === "andijan" ? "#fbbf24" : "#c8e6c9"}
            stroke="#22c55e"
            strokeWidth="2.5"
            className="cursor-pointer transition-all duration-300 hover:brightness-110"
            onMouseEnter={(e) => handleRegionHover(regions[3], e)}
            onMouseLeave={handleMouseLeave}
          />

          {/* Samarkand - Center */}
          <path
            d="M 450 200 L 600 180 L 780 200 L 750 350 L 580 380 L 480 320 Z"
            fill={hoveredRegion === "samarkand" ? "#fbbf24" : "#c8e6c9"}
            stroke="#22c55e"
            strokeWidth="2.5"
            className="cursor-pointer transition-all duration-300 hover:brightness-110"
            onMouseEnter={(e) => handleRegionHover(regions[5], e)}
            onMouseLeave={handleMouseLeave}
          />

          {/* Jizzakh - Center Right */}
          <path
            d="M 600 180 L 780 200 L 820 280 L 750 350 L 580 380 Z"
            fill={hoveredRegion === "jizzakh" ? "#fbbf24" : "#c8e6c9"}
            stroke="#22c55e"
            strokeWidth="2.5"
            className="cursor-pointer transition-all duration-300 hover:brightness-110"
            onMouseEnter={(e) => handleRegionHover(regions[10], e)}
            onMouseLeave={handleMouseLeave}
          />

          {/* Bukhara - Center Bottom */}
          <path
            d="M 300 300 L 450 200 L 480 320 L 450 450 L 280 480 Z"
            fill={hoveredRegion === "bukhara" ? "#fbbf24" : "#c8e6c9"}
            stroke="#22c55e"
            strokeWidth="2.5"
            className="cursor-pointer transition-all duration-300 hover:brightness-110"
            onMouseEnter={(e) => handleRegionHover(regions[6], e)}
            onMouseLeave={handleMouseLeave}
          />

          {/* Kashkadarya - Bottom Center */}
          <path
            d="M 480 320 L 580 380 L 650 500 L 550 550 L 450 450 Z"
            fill={hoveredRegion === "kashkadarya" ? "#fbbf24" : "#c8e6c9"}
            stroke="#22c55e"
            strokeWidth="2.5"
            className="cursor-pointer transition-all duration-300 hover:brightness-110"
            onMouseEnter={(e) => handleRegionHover(regions[8], e)}
            onMouseLeave={handleMouseLeave}
          />

          {/* Surkhondarya - Bottom Right */}
          <path
            d="M 650 500 L 820 280 L 900 400 L 850 550 Z"
            fill={hoveredRegion === "surkhandarya" ? "#fbbf24" : "#c8e6c9"}
            stroke="#22c55e"
            strokeWidth="2.5"
            className="cursor-pointer transition-all duration-300 hover:brightness-110"
            onMouseEnter={(e) => handleRegionHover(regions[9], e)}
            onMouseLeave={handleMouseLeave}
          />

          {/* Region Labels */}
          <text x="180" y="180" textAnchor="middle" className="text-xs font-bold fill-gray-900 dark:fill-white pointer-events-none" fontSize="11">
            Karakalpakstan
          </text>
          <text x="520" y="130" textAnchor="middle" className="text-xs font-bold fill-gray-900 dark:fill-white pointer-events-none" fontSize="11">
            Navoi
          </text>
          <text x="670" y="140" textAnchor="middle" className="text-xs font-bold fill-gray-900 dark:fill-white pointer-events-none" fontSize="11">
            Tashkent Reg.
          </text>
          <text x="795" y="165" textAnchor="middle" className="text-xs font-bold fill-white pointer-events-none" fontSize="10">
            Tashkent
          </text>
          <text x="820" y="180" textAnchor="middle" className="text-xs font-bold fill-gray-900 dark:fill-white pointer-events-none" fontSize="11">
            Namangan
          </text>
          <text x="950" y="210" textAnchor="middle" className="text-xs font-bold fill-gray-900 dark:fill-white pointer-events-none" fontSize="11">
            Fergana
          </text>
          <text x="1050" y="230" textAnchor="middle" className="text-xs font-bold fill-gray-900 dark:fill-white pointer-events-none" fontSize="11">
            Andijan
          </text>
          <text x="620" y="270" textAnchor="middle" className="text-xs font-bold fill-gray-900 dark:fill-white pointer-events-none" fontSize="11">
            Samarkand
          </text>
          <text x="730" y="310" textAnchor="middle" className="text-xs font-bold fill-gray-900 dark:fill-white pointer-events-none" fontSize="11">
            Jizzakh
          </text>
          <text x="380" y="390" textAnchor="middle" className="text-xs font-bold fill-gray-900 dark:fill-white pointer-events-none" fontSize="11">
            Bukhara
          </text>
          <text x="520" y="440" textAnchor="middle" className="text-xs font-bold fill-gray-900 dark:fill-white pointer-events-none" fontSize="11">
            Kashkadarya
          </text>
          <text x="750" y="430" textAnchor="middle" className="text-xs font-bold fill-gray-900 dark:fill-white pointer-events-none" fontSize="11">
            Surkhondarya
          </text>
        </svg>
      </div>

      {/* Tooltip */}
      {tooltip && (
        <div
          className="fixed bg-white dark:bg-gray-800 rounded-2xl shadow-2xl p-4 border-2 border-blue-500 dark:border-blue-400 z-50 w-80 animate-scale-in"
          style={{
            left: `${tooltip.x}px`,
            top: `${tooltip.y}px`,
            transform: "translate(-50%, -100%)",
          }}
        >
          {/* Tooltip Header */}
          <div className="flex items-center gap-2 mb-3">
            <div className="w-3 h-3 bg-blue-500 rounded-full" />
            <h3 className="font-bold text-gray-900 dark:text-white text-lg">
              {tooltip.region.name}
            </h3>
          </div>

          {/* Tooltip Content */}
          <p className="text-sm text-gray-600 dark:text-gray-400 mb-4">
            {tooltip.region.events > 0
              ? `${tooltip.region.events} ecological competition${tooltip.region.events > 1 ? "s" : ""} hosted`
              : "Soon joining the EcoWise network"}
          </p>

          {/* Stats Grid */}
          <div className="grid grid-cols-3 gap-2">
            <div className="bg-blue-50 dark:bg-blue-900/30 rounded-lg p-2 text-center">
              <div className="text-xl font-bold text-blue-600 dark:text-blue-400">
                {tooltip.region.events}
              </div>
              <div className="text-xs text-gray-600 dark:text-gray-400">Events</div>
            </div>
            <div className="bg-emerald-50 dark:bg-emerald-900/30 rounded-lg p-2 text-center">
              <div className="text-xl font-bold text-emerald-600 dark:text-emerald-400">
                {tooltip.region.participants}
              </div>
              <div className="text-xs text-gray-600 dark:text-gray-400">Participants</div>
            </div>
            <div className="bg-purple-50 dark:bg-purple-900/30 rounded-lg p-2 text-center">
              <div className="text-xl font-bold text-purple-600 dark:text-purple-400">
                {tooltip.region.ambassadors}
              </div>
              <div className="text-xs text-gray-600 dark:text-gray-400">Ambassadors</div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
