import { useState, useEffect } from "react";

interface Stat {
  number: number;
  label: string;
  icon: string;
  displayLabel?: string;
}

const stats: Stat[] = [
  { number: 650, label: "Participants", icon: "👥" },
  { number: 100, label: "Volunteers", icon: "🙋", displayLabel: "100+" },
  { number: 7, label: "Regions", icon: "🗺️" },
];

export default function HeroStats() {
  const [displayNumbers, setDisplayNumbers] = useState<{ [key: string]: number }>({});

  useEffect(() => {
    stats.forEach((stat) => {
      const interval = setInterval(() => {
        setDisplayNumbers((prev) => {
          const current = prev[stat.label] || 0;
          if (current < stat.number) {
            return {
              ...prev,
              [stat.label]: Math.min(current + Math.ceil(stat.number / 30), stat.number),
            };
          }
          return prev;
        });
      }, 30);

      return () => clearInterval(interval);
    });
  }, []);

  return (
    <div className="flex justify-center">
      <div className="grid grid-cols-3 gap-8 mt-8">
        {stats.map((stat) => (
          <div
            key={stat.label}
            className="text-center animate-fade-in-up"
          >
            <div className="text-3xl md:text-4xl font-bold text-gradient-ocean mb-2">
              {stat.displayLabel || displayNumbers[stat.label] || 0}
            </div>
            <p className="text-sm md:text-base text-gray-600 dark:text-gray-400 font-medium">
              {stat.icon} {stat.label}
            </p>
          </div>
        ))}
      </div>
    </div>
  );
}
